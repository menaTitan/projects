/* 
file Name:insetionSort.h
Author:  Mena Sergeyous
Description : it provide implementation for insetionSort.cpp
Date: 11/9/2015
*/

#ifndef INSERTIONSORT_H
#define INSERTIONSORT_H

void insertionSort(int Array[], int size);


#endif